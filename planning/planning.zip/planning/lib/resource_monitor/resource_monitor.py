#!/usr/bin/env python

import os
import copy
import time
import matplotlib.pyplot as plt
import math
import numpy as np
import argparse
from matplotlib.ticker import FormatStrFormatter
from matplotlib.ticker import FuncFormatter
import utils
import ConfigParser
import psutil

class ResourceMonitor(object):
    def __init__(self):
        self.config = ConfigParser.ConfigParser()
        self.config.read(utils.config_path)
        self.process_name_list = eval(self.config.get("Monitor", "process_name_list"))
        self.process_launch_time = utils.get_current_time()
        


    def store_resource_usage(self):
        data = {
            "cpu": {},
            "memory": {}
        }
        for process_name in self.process_name_list:
            data["cpu"][process_name] = []
            data["memory"][process_name] = []

        try:
            while True:
                
                cpu_tmp_data = {}

                for process_name in self.process_name_list:
                    pid = utils.get_pid_by_name(process_name)
                    process = copy.deepcopy(psutil.Process(pid))
                    process.cpu_percent(interval=None)
                    cpu_tmp_data[process_name] = []
                    

                    for i in range(10):
                        cpu_tmp_data[process_name].append(process.cpu_percent(interval=0.01))
                    cpu = str(float(sum(cpu_tmp_data[process_name]) / len(cpu_tmp_data[process_name])))
                    memory = str(process.memory_info().rss / 2**20)
                    data["cpu"][process_name].append(cpu)
                    data["memory"][process_name].append(memory)

        except:
            self.draw_resource_usage(data)

                

    def draw_resource_usage(self, data):
        image_path = self.config.get("Path", "image_path")

        min_length = len(utils.get_smallest_length(utils.get_smallest_length(data)))
        time_list = [x for x in range(min_length)]
        
        fig = plt.figure()

        ax1 = fig.add_subplot(111)
        plots = []
        for process_name, process_data in data["cpu"].iteritems():
            process_data = list(map(lambda x: float(x), process_data))
            p = ax1.plot(time_list, process_data[:min_length], label="{0} cpu usage".format(process_name), linewidth=2)
            plots += p
        ax1.set_xlabel('time', fontsize = 30)
        ax1.set_ylabel("cpu usage", fontsize = 30)
        ax1.tick_params(axis="x",labelsize=23)
        ax1.tick_params(axis="y",labelsize=23)
        ax1.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.0%}'.format(y / 100.0))) 
        ax1.set_title("Resource usages", fontsize = 36)

        ax2 = ax1.twinx()
        for process_name, process_data in data["memory"].iteritems():
            process_data = list(map(lambda x: float(x), process_data))
            p = ax2.plot(time_list, process_data[:min_length], label="{0} memory usage".format(process_name), linewidth=4, linestyle='--')
            plots += p
        ax2.set_ylabel("memory usage", fontsize = 30)
        ax2.tick_params(axis="y",labelsize=23)
        ax2.yaxis.set_major_formatter(FormatStrFormatter('%dMb'))
        
        lables = [l.get_label() for l in plots]
        ax1.legend(plots, lables, loc=4, prop={'size': 18})

        plt.tick_params(labelsize=23)
        plt.draw()
        plt.show()


if __name__ == '__main__':
    r = ResourceMonitor()
    r.store_resource_usage()