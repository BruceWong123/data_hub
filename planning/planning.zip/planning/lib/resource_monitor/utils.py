import os
import sys
import time
import pprint
import argparse
from subprocess import check_output
from datetime import datetime

config_path = os.path.abspath(os.path.dirname(__file__)) + "/config.ini"


def get_pid_by_name(pid_name):
    try:
        return int(check_output(["pidof", pid_name]))
    except Exception as e:
        print("Run the process first.")
        exit(0)

def get_current_time():
    return datetime.now().strftime('_%Y_%m_%d_%H_%M')

def create_file_by_path_name_and_time(path, name, time):
    if not os.path.exists(path):
        os.makedirs(path)
    return path + name + time

def get_smallest_length(x):
    return [k for k in x.values() if len(k) == min([len(n) for n in x.values()])][0]
