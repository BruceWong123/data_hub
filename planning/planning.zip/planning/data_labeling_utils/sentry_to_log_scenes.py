import json
import yaml
import argparse
import os
from sentry_path_utils import (
    MakeRosParamsPath,
    MakeLogScenePath,
    MakeRelativeBagPath,
    MakeBagsInfoPath,
    MakeConfigVersionPath,
)

district_abbr_to_full_name = {
    "sz": "shenzhen",
    "wh": "wuhan",
    "hz": "hangzhou",
    "us": "us",
    "xm": "xiamen",
    "xy": "xiangyang",
}


def CorrectMapPath(map_path):
    map_path = map_path.replace(
        "/opt/deeproute/semantic-map/shenzhen/sz-baoan/",
        "/opt/deeproute/semantic-map/shenzhen/sz-baoan/planning/",
    )
    return map_path


def ParseArgs():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--sentry_path", help="input sentry json file path", required=True
    )
    args = parser.parse_args()
    return args


def ReadToDict(file_path, format_lib):
    f = open(file_path, "r")
    json_in_dict = format_lib.load(f)
    f.close()
    return json_in_dict


def DumpFromDict(file_path, data_in_dict, format_lib):
    f = open(file_path, "w")
    try:
        format_lib.dump(data_in_dict, f, indent=4)
    except:
        format_lib.dump(data_in_dict, f)
    f.close()


def MakeMapPathandVersion(sentry_dict):
    try:
        map_version = sentry_dict["map_version"].split("-")[0]
        map_name = sentry_dict["map"]
        district_abbr = map_name.split("-")[0]
        district_full = district_abbr_to_full_name[district_abbr]
        map_path = (
            "/opt/deeproute/semantic-map/"
            + district_full
            + "/"
            + map_name
            + "/"
            + map_version
            + "/"
            + map_name
            + ".bin"
        )
        map_path = CorrectMapPath(map_path)
    except:
        map_path = "null"
        map_version = "null"
    return map_path, map_version


def MakeParseConfig(ros_params_path):
    parse_config = "/opt/deeproute/planning/share/tests/launch/jsonnet/planner_sz_baoan_ces_loop.jsonnet"
    try:
        ros_params_dict = ReadToDict(ros_params_path, yaml)
        parse_config = ros_params_dict["parse_config"]
    except:
        print(
            "Failed to parse 'parse_config'. Use default parse_config: " + parse_config
        )
    return parse_config


def FindBagInfo(sentry_dict, bags_info_list):
    system_time = sentry_dict["system_time"]
    for bag_info_dict in bags_info_list:
        if (
            bag_info_dict["time"]["start_time"]
            <= system_time
            <= bag_info_dict["time"]["end_time"]
            and bag_info_dict["bag_name"] in sentry_dict["bags_name"]
        ):
            return bag_info_dict
    return None


def MakeIncidentStartTime(sentry_dict, sentry_path):
    bags_info_path = MakeBagsInfoPath(sentry_path)
    bags_info_list = ReadToDict(bags_info_path, json)
    if type(bags_info_list) != list:
        raise Exception("Invalid bags_info.")
    bag_info_dict = FindBagInfo(sentry_dict, bags_info_list)
    if bag_info_dict == None:
        raise Exception("Find bag info failed")
    bag_start_system_time = bag_info_dict["time"]["start_time"]
    incident_start_time = sentry_dict["system_time"] - bag_start_system_time
    return incident_start_time


def MakeCarConfigVersion(sentry_path):
    config_version_path = MakeConfigVersionPath(sentry_path)
    config_version_dict = ReadToDict(config_version_path, yaml)
    return config_version_dict["car_config"]


def MakeLogSceneDict(sentry_dict, parse_config, sentry_path):
    log_scene_dict = dict()
    log_scene_dict["id"] = 0
    log_scene_dict["bag_path"] = MakeRelativeBagPath(
        sentry_path, sentry_dict["bags_name"][0]
    )
    log_scene_dict["server"] = "FTP"
    log_scene_dict["scene_type"] = []
    log_scene_dict["incident_start_time"] = MakeIncidentStartTime(
        sentry_dict, sentry_path
    )
    log_scene_dict["open_loop_start_time"] = sentry_dict["open_loop_start_time"]
    log_scene_dict["close_loop_start_time"] = sentry_dict["close_loop_start_time"]
    log_scene_dict["duration"] = sentry_dict["duration"]
    log_scene_dict["map_path"], log_scene_dict["map_version"] = MakeMapPathandVersion(
        sentry_dict
    )
    log_scene_dict["description"] = "JIRA QA-*"
    log_scene_dict["parse_config"] = parse_config
    log_scene_dict["car_id"] = sentry_dict["car_id"]
    log_scene_dict["config_car_version"] = MakeCarConfigVersion(sentry_path)
    return log_scene_dict


def IsPNCCase(sentry_dict):
    return "tag_group" in sentry_dict and sentry_dict["tag_group"] == "pnc"


def MakeLogScenesDict(sentry_path, ros_params_path):
    parse_config = MakeParseConfig(ros_params_path)
    sentry_dict = ReadToDict(sentry_path, json)
    log_scenes_dict = {"log_scenes": []}
    log_scenes_list = log_scenes_dict["log_scenes"]

    for sentry_one_case in sentry_dict:
        if IsPNCCase(sentry_one_case):
            log_scene_dict = MakeLogSceneDict(
                sentry_one_case, parse_config, sentry_path
            )
            log_scenes_list.append(log_scene_dict)

    return log_scenes_dict


if __name__ == "__main__":
    args = ParseArgs()
    sentry_path = args.sentry_path
    ros_params_path = MakeRosParamsPath(sentry_path)
    log_scenes_path = MakeLogScenePath(sentry_path)
    log_scenes_dict = MakeLogScenesDict(sentry_path, ros_params_path)
    DumpFromDict(log_scenes_path, log_scenes_dict, json)
