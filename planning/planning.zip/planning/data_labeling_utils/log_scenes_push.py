import sys
import time
import subprocess
import os
import json
from ftplib import FTP
from enum import Enum
import argparse
import time
from sentry_path_utils import (
    MakeBagRootPath,
    IsSentryDirectory,
    RemoveRelativePathPrefix,
    relative_path_prefix,
)


class ServerType(Enum):
    FTP = "FTP"
    PIPELINE = "PIPELINE"


parser = argparse.ArgumentParser(
    description="Cut bags and upload to server for log sim. "
    "If the bag has been cut before, it won't be cut again and won't be uploaded. You can change it using -[options]"
)

parser.add_argument(
    "-i",
    metavar="id",
    nargs="+",
    help="cut and upload bags only for given id",
    type=int,
)
parser.add_argument(
    "-f", "--force", action="store_true", help="force to cut bag again and upload again"
)
parser.add_argument("-u", "--upload", action="store_true", help="force to upload again")
parser.add_argument("--log_scenes_path", help="path of log scenes json", required=True)
args = parser.parse_args()


if "FTPUSER" not in os.environ:
    print ("please set FTPUSER as env var!")
    exit()
if "FTPPW" not in os.environ:
    print ("please set FTPPW as env var!")
    exit()

ftp_addr = "10.3.2.253"

print "Trying to connect ftp://" + ftp_addr
ftp = FTP(ftp_addr)
ftp.login(os.environ["FTPUSER"], os.environ["FTPPW"])
print "Connected."
print " "


def ftp_cd(target_dir):
    if target_dir != "":
        try:
            ftp.cwd(target_dir)
        except:
            ftp_cd("/".join(target_dir.split("/")[:-1]))
            ftp.mkd(target_dir.split("/")[-1])
            ftp.cwd(target_dir.split("/")[-1])


def append_time_to_json_filename(json_filename):
    filename_without_extension = json_filename.split(".json")[0]
    filename_without_extension += "_" + time.strftime("%H:%M:%S", time.localtime())
    new_json_filename = filename_without_extension + ".json"
    return new_json_filename


def upload_log_scenes():
    date = time.strftime("%Y-%m-%d", time.localtime())
    ftp_log_scenes_dir = "/bag/log_scenes/json/" + date
    ftp_cd(ftp_log_scenes_dir)
    log_scenes_filename = args.log_scenes_path.split("/")[-1]
    ftp_log_scenes_path = (
        "ftp://"
        + ftp_addr
        + ftp_log_scenes_dir
        + "/"
        + append_time_to_json_filename(log_scenes_filename)
    )
    print (
        "Upload log_scenes json. Source: "
        + args.log_scenes_path
        + ". Target: "
        + ftp_log_scenes_path
        + "."
    )
    command = (
        "curl --user "
        + os.environ["FTPUSER"]
        + ":"
        + os.environ["FTPPW"]
        + " -T "
        + args.log_scenes_path
        + " --ftp-create-dirs "
        + ftp_log_scenes_path
    )
    subprocess.call(command, shell=True)


if __name__ == "__main__":
    if not IsSentryDirectory(os.path.dirname(args.log_scenes_path)):
        raise Exception("log_scenes_path not in sentry directory.")
    bag_root_path = MakeBagRootPath(args.log_scenes_path)
    print "Update log sim bags using local bag path: ", bag_root_path
    print " "

    ## Read log scene file
    with open(args.log_scenes_path) as f:
        log_scenes = json.load(f)

    for scene in log_scenes["log_scenes"]:
        scene_id = scene["id"]
        scene_bag_path = RemoveRelativePathPrefix(scene["bag_path"])
        scene_open_loop_start_time = scene["open_loop_start_time"]
        scene_duration = scene["duration"]
        scene_server = scene["server"]

        if bool(args.i) and scene_id not in args.i:
            continue

        new_bag_created = False
        print "scene " + str(scene_id) + ": " + scene_bag_path

        ## Ignore locally non-existed bag
        original_bag = bag_root_path + "/" + scene_bag_path
        if not os.path.isfile(original_bag):
            print "    Ignored because it doesn't exist locally."
            print " "
            continue

        ## Fetch bag
        bag_name = scene_bag_path[scene_bag_path.rfind("/") + 1 :]
        if bag_name[-4:] != ".bag":
            print "    Error: unsupported bag file type: ", scene_bag_path
            exit()

        ## Create new bag name
        bag_dir = scene_bag_path[: scene_bag_path.rfind("/")]
        bag_full_dir = bag_root_path + "/" + bag_dir
        new_bag_name = (
            bag_name[:-4]
            + "_"
            + str(int(scene_open_loop_start_time))
            + "_"
            + str(int(scene_duration))
            + ".bag"
        )
        new_bag = bag_full_dir + "/log_sim/" + new_bag_name

        ## Create log sim bag
        if args.force or not os.path.isfile(new_bag):
            ## Create log_sim directory
            if not os.path.isdir(bag_full_dir + "/log_sim"):
                os.mkdir(bag_full_dir + "/log_sim")
                print "    Created directory:", bag_full_dir + "/log_sim"

            # Get bag time
            proc = subprocess.Popen(
                "rosbag info -y -k start " + original_bag,
                stdout=subprocess.PIPE,
                shell=True,
            )
            (out, err) = proc.communicate()
            bag_initial_time = float(out)
            proc = subprocess.Popen(
                "rosbag info -y -k duration " + original_bag,
                stdout=subprocess.PIPE,
                shell=True,
            )
            (out, err) = proc.communicate()
            bag_duration = float(out)
            print "    start time: ", scene_open_loop_start_time
            print "    duration: ", scene_duration
            print "    bag duration: ", bag_duration

            if scene_open_loop_start_time + scene_duration > bag_duration:
                print "    Error: log sim time exceeds the bag time."
                exit()

            start_time = bag_initial_time + scene_open_loop_start_time
            end_time = start_time + scene_duration
            print "    bag start time: ", start_time
            print "    bag end time: ", end_time

            # Topic list
            topics = [
                "/canbus/car_info",
                "/canbus/car_state",
                "/control/control_command",
                "/perception/objects",
                "/perception/signals_response",
                "/sensors/gnss/pose",
                "/planner/routing_response",
                "/planner/debug_info",
                "/planner/trajectory",
                "/planner/rqt_info",
            ]
            print "    target topics: ", topics

            # Execute filter
            print "    Filtering the bag..."
            command = "rosbag filter " + original_bag + " " + new_bag + ' "('
            for i in range(len(topics)):
                if i > 0:
                    command += " or "
                command += "topic == '" + topics[i] + "'"
            command += (
                ") and t.to_sec() >= "
                + str(start_time)
                + " and t.to_sec() <= "
                + str(end_time)
                + '"'
            )
            subprocess.call(command, shell=True)
            new_bag_created = True
            print "    done."

        # Upload to server
        if new_bag_created or args.force or args.upload:
            if scene_server == ServerType.FTP.value:
                print "    ServerType: ", ServerType.FTP.name
                ftp_bag_dir = "/bag/" + relative_path_prefix + bag_dir + "/log_sim"
                # Upload to FTP
                if not args.force and not args.upload:
                    # not in force upload mode
                    print "    Check if bag exists on FTP..."
                    ftp_cd(ftp_bag_dir)
                    if new_bag_name in ftp.nlst():
                        print "    Already existed on FTP."
                        continue
                    else:
                        print "    Doesn't exist. "
                print "    Now uploading..."
                # note: only Test Group has the upload permission
                command = (
                    "curl --user "
                    + os.environ["FTPUSER"]
                    + ":"
                    + os.environ["FTPPW"]
                    + " -T "
                    + new_bag
                    + " --ftp-create-dirs ftp://"
                    + ftp_addr
                    + ftp_bag_dir
                    + "/"
                    + new_bag_name
                )
                subprocess.call(command, shell=True)
                print "    Uploaded."
            elif scene_server == ServerType.PIPELINE.value:
                print "    ServerType: ", ServerType.PIPELINE.name
                # to do
                print "    Not supported yet."
            else:
                print "Unknown server name."
                exit()
        else:
            print "    Ignored because the log sim bag already existed."
        print " "

    upload_log_scenes()

    ftp.close()
    print "Done."

