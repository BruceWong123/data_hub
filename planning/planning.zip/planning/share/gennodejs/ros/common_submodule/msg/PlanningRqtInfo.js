// Auto-generated. Do not edit!

// (in-package common_submodule.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PlanningRqtInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.x = null;
      this.y = null;
      this.z = null;
      this.s = null;
      this.l = null;
      this.vx = null;
      this.vy = null;
      this.roll = null;
      this.pitch = null;
      this.yaw = null;
      this.roll_rate = null;
      this.pitch_rate = null;
      this.yaw_rate = null;
      this.ax = null;
      this.ay = null;
      this.speed = null;
      this.acc = null;
      this.front_wheel_angle = null;
      this.stwl_angle_rate = null;
      this.start_time = null;
      this.cur_time = null;
      this.flag_init = null;
      this.iter_count = null;
      this.dist_outside_left = null;
      this.dist_outside_right = null;
      this.end_of_stitch_speed = null;
      this.end_of_stitch_steer_angle = null;
      this.end_of_stitch_steer_rate = null;
      this.jx = null;
      this.jy = null;
    }
    else {
      if (initObj.hasOwnProperty('x')) {
        this.x = initObj.x
      }
      else {
        this.x = 0.0;
      }
      if (initObj.hasOwnProperty('y')) {
        this.y = initObj.y
      }
      else {
        this.y = 0.0;
      }
      if (initObj.hasOwnProperty('z')) {
        this.z = initObj.z
      }
      else {
        this.z = 0.0;
      }
      if (initObj.hasOwnProperty('s')) {
        this.s = initObj.s
      }
      else {
        this.s = 0.0;
      }
      if (initObj.hasOwnProperty('l')) {
        this.l = initObj.l
      }
      else {
        this.l = 0.0;
      }
      if (initObj.hasOwnProperty('vx')) {
        this.vx = initObj.vx
      }
      else {
        this.vx = 0.0;
      }
      if (initObj.hasOwnProperty('vy')) {
        this.vy = initObj.vy
      }
      else {
        this.vy = 0.0;
      }
      if (initObj.hasOwnProperty('roll')) {
        this.roll = initObj.roll
      }
      else {
        this.roll = 0.0;
      }
      if (initObj.hasOwnProperty('pitch')) {
        this.pitch = initObj.pitch
      }
      else {
        this.pitch = 0.0;
      }
      if (initObj.hasOwnProperty('yaw')) {
        this.yaw = initObj.yaw
      }
      else {
        this.yaw = 0.0;
      }
      if (initObj.hasOwnProperty('roll_rate')) {
        this.roll_rate = initObj.roll_rate
      }
      else {
        this.roll_rate = 0.0;
      }
      if (initObj.hasOwnProperty('pitch_rate')) {
        this.pitch_rate = initObj.pitch_rate
      }
      else {
        this.pitch_rate = 0.0;
      }
      if (initObj.hasOwnProperty('yaw_rate')) {
        this.yaw_rate = initObj.yaw_rate
      }
      else {
        this.yaw_rate = 0.0;
      }
      if (initObj.hasOwnProperty('ax')) {
        this.ax = initObj.ax
      }
      else {
        this.ax = 0.0;
      }
      if (initObj.hasOwnProperty('ay')) {
        this.ay = initObj.ay
      }
      else {
        this.ay = 0.0;
      }
      if (initObj.hasOwnProperty('speed')) {
        this.speed = initObj.speed
      }
      else {
        this.speed = 0.0;
      }
      if (initObj.hasOwnProperty('acc')) {
        this.acc = initObj.acc
      }
      else {
        this.acc = 0.0;
      }
      if (initObj.hasOwnProperty('front_wheel_angle')) {
        this.front_wheel_angle = initObj.front_wheel_angle
      }
      else {
        this.front_wheel_angle = 0.0;
      }
      if (initObj.hasOwnProperty('stwl_angle_rate')) {
        this.stwl_angle_rate = initObj.stwl_angle_rate
      }
      else {
        this.stwl_angle_rate = 0.0;
      }
      if (initObj.hasOwnProperty('start_time')) {
        this.start_time = initObj.start_time
      }
      else {
        this.start_time = 0.0;
      }
      if (initObj.hasOwnProperty('cur_time')) {
        this.cur_time = initObj.cur_time
      }
      else {
        this.cur_time = 0.0;
      }
      if (initObj.hasOwnProperty('flag_init')) {
        this.flag_init = initObj.flag_init
      }
      else {
        this.flag_init = 0;
      }
      if (initObj.hasOwnProperty('iter_count')) {
        this.iter_count = initObj.iter_count
      }
      else {
        this.iter_count = 0;
      }
      if (initObj.hasOwnProperty('dist_outside_left')) {
        this.dist_outside_left = initObj.dist_outside_left
      }
      else {
        this.dist_outside_left = 0.0;
      }
      if (initObj.hasOwnProperty('dist_outside_right')) {
        this.dist_outside_right = initObj.dist_outside_right
      }
      else {
        this.dist_outside_right = 0.0;
      }
      if (initObj.hasOwnProperty('end_of_stitch_speed')) {
        this.end_of_stitch_speed = initObj.end_of_stitch_speed
      }
      else {
        this.end_of_stitch_speed = 0.0;
      }
      if (initObj.hasOwnProperty('end_of_stitch_steer_angle')) {
        this.end_of_stitch_steer_angle = initObj.end_of_stitch_steer_angle
      }
      else {
        this.end_of_stitch_steer_angle = 0.0;
      }
      if (initObj.hasOwnProperty('end_of_stitch_steer_rate')) {
        this.end_of_stitch_steer_rate = initObj.end_of_stitch_steer_rate
      }
      else {
        this.end_of_stitch_steer_rate = 0.0;
      }
      if (initObj.hasOwnProperty('jx')) {
        this.jx = initObj.jx
      }
      else {
        this.jx = 0.0;
      }
      if (initObj.hasOwnProperty('jy')) {
        this.jy = initObj.jy
      }
      else {
        this.jy = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PlanningRqtInfo
    // Serialize message field [x]
    bufferOffset = _serializer.float64(obj.x, buffer, bufferOffset);
    // Serialize message field [y]
    bufferOffset = _serializer.float64(obj.y, buffer, bufferOffset);
    // Serialize message field [z]
    bufferOffset = _serializer.float64(obj.z, buffer, bufferOffset);
    // Serialize message field [s]
    bufferOffset = _serializer.float64(obj.s, buffer, bufferOffset);
    // Serialize message field [l]
    bufferOffset = _serializer.float64(obj.l, buffer, bufferOffset);
    // Serialize message field [vx]
    bufferOffset = _serializer.float64(obj.vx, buffer, bufferOffset);
    // Serialize message field [vy]
    bufferOffset = _serializer.float64(obj.vy, buffer, bufferOffset);
    // Serialize message field [roll]
    bufferOffset = _serializer.float64(obj.roll, buffer, bufferOffset);
    // Serialize message field [pitch]
    bufferOffset = _serializer.float64(obj.pitch, buffer, bufferOffset);
    // Serialize message field [yaw]
    bufferOffset = _serializer.float64(obj.yaw, buffer, bufferOffset);
    // Serialize message field [roll_rate]
    bufferOffset = _serializer.float64(obj.roll_rate, buffer, bufferOffset);
    // Serialize message field [pitch_rate]
    bufferOffset = _serializer.float64(obj.pitch_rate, buffer, bufferOffset);
    // Serialize message field [yaw_rate]
    bufferOffset = _serializer.float64(obj.yaw_rate, buffer, bufferOffset);
    // Serialize message field [ax]
    bufferOffset = _serializer.float64(obj.ax, buffer, bufferOffset);
    // Serialize message field [ay]
    bufferOffset = _serializer.float64(obj.ay, buffer, bufferOffset);
    // Serialize message field [speed]
    bufferOffset = _serializer.float64(obj.speed, buffer, bufferOffset);
    // Serialize message field [acc]
    bufferOffset = _serializer.float64(obj.acc, buffer, bufferOffset);
    // Serialize message field [front_wheel_angle]
    bufferOffset = _serializer.float64(obj.front_wheel_angle, buffer, bufferOffset);
    // Serialize message field [stwl_angle_rate]
    bufferOffset = _serializer.float64(obj.stwl_angle_rate, buffer, bufferOffset);
    // Serialize message field [start_time]
    bufferOffset = _serializer.float64(obj.start_time, buffer, bufferOffset);
    // Serialize message field [cur_time]
    bufferOffset = _serializer.float64(obj.cur_time, buffer, bufferOffset);
    // Serialize message field [flag_init]
    bufferOffset = _serializer.uint8(obj.flag_init, buffer, bufferOffset);
    // Serialize message field [iter_count]
    bufferOffset = _serializer.uint64(obj.iter_count, buffer, bufferOffset);
    // Serialize message field [dist_outside_left]
    bufferOffset = _serializer.float64(obj.dist_outside_left, buffer, bufferOffset);
    // Serialize message field [dist_outside_right]
    bufferOffset = _serializer.float64(obj.dist_outside_right, buffer, bufferOffset);
    // Serialize message field [end_of_stitch_speed]
    bufferOffset = _serializer.float64(obj.end_of_stitch_speed, buffer, bufferOffset);
    // Serialize message field [end_of_stitch_steer_angle]
    bufferOffset = _serializer.float64(obj.end_of_stitch_steer_angle, buffer, bufferOffset);
    // Serialize message field [end_of_stitch_steer_rate]
    bufferOffset = _serializer.float64(obj.end_of_stitch_steer_rate, buffer, bufferOffset);
    // Serialize message field [jx]
    bufferOffset = _serializer.float64(obj.jx, buffer, bufferOffset);
    // Serialize message field [jy]
    bufferOffset = _serializer.float64(obj.jy, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PlanningRqtInfo
    let len;
    let data = new PlanningRqtInfo(null);
    // Deserialize message field [x]
    data.x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [y]
    data.y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [z]
    data.z = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [s]
    data.s = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [l]
    data.l = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [vx]
    data.vx = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [vy]
    data.vy = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [roll]
    data.roll = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [pitch]
    data.pitch = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [yaw]
    data.yaw = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [roll_rate]
    data.roll_rate = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [pitch_rate]
    data.pitch_rate = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [yaw_rate]
    data.yaw_rate = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [ax]
    data.ax = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [ay]
    data.ay = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [speed]
    data.speed = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [acc]
    data.acc = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [front_wheel_angle]
    data.front_wheel_angle = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [stwl_angle_rate]
    data.stwl_angle_rate = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [start_time]
    data.start_time = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [cur_time]
    data.cur_time = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [flag_init]
    data.flag_init = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [iter_count]
    data.iter_count = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [dist_outside_left]
    data.dist_outside_left = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dist_outside_right]
    data.dist_outside_right = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [end_of_stitch_speed]
    data.end_of_stitch_speed = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [end_of_stitch_steer_angle]
    data.end_of_stitch_steer_angle = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [end_of_stitch_steer_rate]
    data.end_of_stitch_steer_rate = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [jx]
    data.jx = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [jy]
    data.jy = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 233;
  }

  static datatype() {
    // Returns string type for a message object
    return 'common_submodule/PlanningRqtInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f5bf47ff74f8f76ed6fab8e4409bb795';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 x
    float64 y
    float64 z
    float64 s
    float64 l
    float64 vx
    float64 vy
    float64 roll
    float64 pitch
    float64 yaw
    float64 roll_rate
    float64 pitch_rate
    float64 yaw_rate
    float64 ax
    float64 ay
    float64 speed
    float64 acc
    float64 front_wheel_angle
    float64 stwl_angle_rate
    float64 start_time
    float64 cur_time
    uint8 flag_init
    uint64 iter_count
    float64 dist_outside_left
    float64 dist_outside_right
    float64 end_of_stitch_speed
    float64 end_of_stitch_steer_angle
    float64 end_of_stitch_steer_rate
    float64 jx
    float64 jy
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PlanningRqtInfo(null);
    if (msg.x !== undefined) {
      resolved.x = msg.x;
    }
    else {
      resolved.x = 0.0
    }

    if (msg.y !== undefined) {
      resolved.y = msg.y;
    }
    else {
      resolved.y = 0.0
    }

    if (msg.z !== undefined) {
      resolved.z = msg.z;
    }
    else {
      resolved.z = 0.0
    }

    if (msg.s !== undefined) {
      resolved.s = msg.s;
    }
    else {
      resolved.s = 0.0
    }

    if (msg.l !== undefined) {
      resolved.l = msg.l;
    }
    else {
      resolved.l = 0.0
    }

    if (msg.vx !== undefined) {
      resolved.vx = msg.vx;
    }
    else {
      resolved.vx = 0.0
    }

    if (msg.vy !== undefined) {
      resolved.vy = msg.vy;
    }
    else {
      resolved.vy = 0.0
    }

    if (msg.roll !== undefined) {
      resolved.roll = msg.roll;
    }
    else {
      resolved.roll = 0.0
    }

    if (msg.pitch !== undefined) {
      resolved.pitch = msg.pitch;
    }
    else {
      resolved.pitch = 0.0
    }

    if (msg.yaw !== undefined) {
      resolved.yaw = msg.yaw;
    }
    else {
      resolved.yaw = 0.0
    }

    if (msg.roll_rate !== undefined) {
      resolved.roll_rate = msg.roll_rate;
    }
    else {
      resolved.roll_rate = 0.0
    }

    if (msg.pitch_rate !== undefined) {
      resolved.pitch_rate = msg.pitch_rate;
    }
    else {
      resolved.pitch_rate = 0.0
    }

    if (msg.yaw_rate !== undefined) {
      resolved.yaw_rate = msg.yaw_rate;
    }
    else {
      resolved.yaw_rate = 0.0
    }

    if (msg.ax !== undefined) {
      resolved.ax = msg.ax;
    }
    else {
      resolved.ax = 0.0
    }

    if (msg.ay !== undefined) {
      resolved.ay = msg.ay;
    }
    else {
      resolved.ay = 0.0
    }

    if (msg.speed !== undefined) {
      resolved.speed = msg.speed;
    }
    else {
      resolved.speed = 0.0
    }

    if (msg.acc !== undefined) {
      resolved.acc = msg.acc;
    }
    else {
      resolved.acc = 0.0
    }

    if (msg.front_wheel_angle !== undefined) {
      resolved.front_wheel_angle = msg.front_wheel_angle;
    }
    else {
      resolved.front_wheel_angle = 0.0
    }

    if (msg.stwl_angle_rate !== undefined) {
      resolved.stwl_angle_rate = msg.stwl_angle_rate;
    }
    else {
      resolved.stwl_angle_rate = 0.0
    }

    if (msg.start_time !== undefined) {
      resolved.start_time = msg.start_time;
    }
    else {
      resolved.start_time = 0.0
    }

    if (msg.cur_time !== undefined) {
      resolved.cur_time = msg.cur_time;
    }
    else {
      resolved.cur_time = 0.0
    }

    if (msg.flag_init !== undefined) {
      resolved.flag_init = msg.flag_init;
    }
    else {
      resolved.flag_init = 0
    }

    if (msg.iter_count !== undefined) {
      resolved.iter_count = msg.iter_count;
    }
    else {
      resolved.iter_count = 0
    }

    if (msg.dist_outside_left !== undefined) {
      resolved.dist_outside_left = msg.dist_outside_left;
    }
    else {
      resolved.dist_outside_left = 0.0
    }

    if (msg.dist_outside_right !== undefined) {
      resolved.dist_outside_right = msg.dist_outside_right;
    }
    else {
      resolved.dist_outside_right = 0.0
    }

    if (msg.end_of_stitch_speed !== undefined) {
      resolved.end_of_stitch_speed = msg.end_of_stitch_speed;
    }
    else {
      resolved.end_of_stitch_speed = 0.0
    }

    if (msg.end_of_stitch_steer_angle !== undefined) {
      resolved.end_of_stitch_steer_angle = msg.end_of_stitch_steer_angle;
    }
    else {
      resolved.end_of_stitch_steer_angle = 0.0
    }

    if (msg.end_of_stitch_steer_rate !== undefined) {
      resolved.end_of_stitch_steer_rate = msg.end_of_stitch_steer_rate;
    }
    else {
      resolved.end_of_stitch_steer_rate = 0.0
    }

    if (msg.jx !== undefined) {
      resolved.jx = msg.jx;
    }
    else {
      resolved.jx = 0.0
    }

    if (msg.jy !== undefined) {
      resolved.jy = msg.jy;
    }
    else {
      resolved.jy = 0.0
    }

    return resolved;
    }
};

module.exports = PlanningRqtInfo;
