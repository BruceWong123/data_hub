
"use strict";

module.exports = {
  msg: require('./msg/_index.js'),
};
