#!/usr/bin/env python

import os
import sys
import copy
import time
import math
import psutil
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
from subprocess import check_output
from matplotlib.ticker import FormatStrFormatter
from matplotlib.ticker import FuncFormatter


def get_pid_by_name(pid_name):
    try:
        return int(check_output(["pidof", pid_name]))
    except Exception as e:
        print("Run the process first.")
        exit(0)


def get_current_time():
    return datetime.now().strftime("_%Y_%m_%d_%H_%M")


def make_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def create_file_by_path_name_and_time(path, name, time):
    make_dir(path)
    return path + name + time


def get_smallest_length(x):
    return [k for k in x.values() if len(k) == min([len(n) for n in x.values()])][0]


def delay_to_wait_process_launch():
    time.sleep(10)


class ResourceMonitor(object):
    def __init__(self):
        self.process_launch_time = get_current_time()
        self.image_store_path = "/tmp/resource_monitor_results/images/"
        self.process_name_list = [
            "frame_test",
            "rviz",
            "play"
        ]

    def filter_not_running_process(self):
        self.process_name_list = list(filter(lambda x: x in (
            p.name() for p in psutil.process_iter()), self.process_name_list))
        if self.process_name_list == []:
            raise Exception("Run the process first.")

    def store_resource_usage(self):
        delay_to_wait_process_launch()

        self.filter_not_running_process()

        data = {
            "cpu": {},
            "memory": {}
        }
        for process_name in self.process_name_list:
            data["cpu"][process_name] = []
            data["memory"][process_name] = []

        try:
            while True:

                cpu_tmp_data = {}

                for process_name in self.process_name_list:
                    pid = get_pid_by_name(process_name)
                    process = copy.deepcopy(psutil.Process(pid))
                    process.cpu_percent(interval=None)
                    cpu_tmp_data[process_name] = []

                    for i in range(10):
                        cpu_tmp_data[process_name].append(
                            process.cpu_percent(interval=0.01))
                    cpu = str(
                        float(sum(cpu_tmp_data[process_name]) / len(cpu_tmp_data[process_name])))
                    memory = str(process.memory_info().rss / 2**20)
                    data["cpu"][process_name].append(cpu)
                    data["memory"][process_name].append(memory)

        except:
            self.draw_resource_usage(data)

    def draw_resource_usage(self, data):

        min_length = len(get_smallest_length(get_smallest_length(data)))
        time_list = [x for x in range(min_length)]
        fig = plt.figure(figsize=(19.2, 10.8), dpi=100)

        ax1 = fig.add_subplot(111)
        plots = []
        for process_name, process_data in data["cpu"].iteritems():
            process_data = list(map(lambda x: float(x), process_data))
            p = ax1.plot(time_list, process_data[:min_length], label="{0} cpu usage".format(
                process_name), linewidth=2)
            plots += p
        ax1.set_xlabel("time", fontsize=30)
        ax1.set_ylabel("cpu usage", fontsize=30)
        ax1.tick_params(axis="x", labelsize=23)
        ax1.tick_params(axis="y", labelsize=23)
        ax1.yaxis.set_major_formatter(FuncFormatter(
            lambda y, _: "{:.0%}".format(y / 100.0)))
        ax1.set_title("Resource usages", fontsize=36)

        ax2 = ax1.twinx()
        for process_name, process_data in data["memory"].iteritems():
            process_data = list(map(lambda x: float(x), process_data))
            p = ax2.plot(time_list, process_data[:min_length], label="{0} memory usage".format(
                process_name), linewidth=4, linestyle="--")
            plots += p
        ax2.set_ylabel("memory usage", fontsize=30)
        ax2.tick_params(axis="y", labelsize=23)
        ax2.yaxis.set_major_formatter(FormatStrFormatter("%dMb"))

        lables = [l.get_label() for l in plots]
        ax1.legend(plots, lables, loc=0, prop={"size": 18})

        plt.tick_params(labelsize=23)
        plt.draw()

        image_name = self.image_store_path + self.process_launch_time + ".png"
        make_dir(self.image_store_path)
        plt.get_current_fig_manager().full_screen_toggle()
        plt.savefig(image_name)
        print ("Resource usage image has been stored to {0}".format(image_name))


if __name__ == "__main__":
    r = ResourceMonitor()
    r.store_resource_usage()
