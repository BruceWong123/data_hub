import os

path_to_bag_layer_number = 5
relative_path_prefix = "log_scenes/"


def MakeRosParamsPath(sentry_path):
    ros_params_dir = os.path.dirname(os.path.dirname(os.path.dirname(sentry_path)))
    ros_params_path = ros_params_dir + "/rosparams"
    return ros_params_path


def MakeLogScenePath(sentry_path):
    log_scenes_path = os.path.dirname(sentry_path) + "/log_scenes.json"
    return log_scenes_path


def MakeBagsInfoPath(sentry_path):
    bags_info_dir = os.path.dirname(os.path.dirname(sentry_path))
    bags_info_path = bags_info_dir + "/bags_info.json"
    return bags_info_path


def MakeConfigVersionPath(sentry_path):
    config_folder_dir = os.path.dirname(os.path.dirname(os.path.dirname(sentry_path)))
    config_version_path = config_folder_dir + "/config/config.version"
    return config_version_path


def MakeRelativeBagPath(sentry_path, bag_name, with_prefix=True):
    sentry_dir = os.path.dirname(sentry_path)
    folder_names = sentry_dir.split("/")
    if len(folder_names) < path_to_bag_layer_number:
        raise Exception("Cannot make bag path.")
    bag_path = relative_path_prefix if with_prefix else ""
    for i in range(-path_to_bag_layer_number + 1, 0):
        bag_path += folder_names[i] + "/"
    bag_path += bag_name
    return bag_path


def RemoveRelativePathPrefix(relative_path):
    if relative_path.find(relative_path_prefix) == 0:
        relative_path = relative_path[len(relative_path_prefix) :]
    return relative_path


def MakeBagRootPath(sentry_path):
    bag_root_path = sentry_path
    for _ in range(5):
        bag_root_path = os.path.dirname(bag_root_path)
    return bag_root_path


def IsSentryDirectory(directory):
    sentry_path = directory + "/important.json"
    return os.path.isfile(sentry_path)
