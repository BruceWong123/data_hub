import argparse
import subprocess
import os
from signal import SIGINT
import time
import json

FNULL = open(os.devnull, "w")


def ParseArgs():
    parser = argparse.ArgumentParser()

    parser.add_argument("--map_path", help="map used for the bag")
    parser.add_argument("--bags", nargs="+", help="bags to play", required=True)
    parser.add_argument("-r", "--rate", help="play speed rate", type=float)
    parser.add_argument(
        "-s", "--start", help="start SEC seconds into the bag files", type=float
    )
    parser.add_argument(
        "-u", "--duration", help="play only SEC seconds from the bag files", type=float
    )
    parser.add_argument("--norviz", action="store_true", help="no rviz")
    parser.add_argument("--norqt", action="store_true", help="no rqt_multiplot")
    parser.add_argument("--pause", action="store_true", help="starting in pause mode")
    args = parser.parse_args()
    return args


def GetMapPath(args):
    try:
        from sentry_to_log_scenes import MakeMapPathandVersion

        sentry_dir = os.path.dirname(args.bags[0])
        sentry_path = sentry_dir + "/important.json"
        with open(sentry_path, "r") as f:
            sentry_dict = json.load(f)[0]
        map_path, _ = MakeMapPathandVersion(sentry_dict)
    except:
        map_path = args.map_path

    return map_path


def MakeBagPlayCmd(args):
    bag_play_bin = "/opt/deeproute/planning/lib/tools/bag_play"
    bags = ""
    for bag in args.bags:
        bags += " " + bag
    bag_play_cmd = (
        bag_play_bin
        + bags
        + (" --map_path " + GetMapPath(args))
        + ((" -r " + str(args.rate)) if args.rate > 0 else "")
        + ((" -s " + str(args.start)) if args.start > 0 else "")
        + ((" -u " + str(args.duration)) if args.duration > 0 else "")
        + (" --pause" if args.pause else "")
    )
    return bag_play_cmd


def MakeRvizCmd():
    rviz_cmd = "rviz -d /opt/deeproute/planning/share/rviz_visualizer/prediction.rviz"
    return rviz_cmd


def MakeRqtMultiPlotCmd():
    rqt_multiplot_cmd = "/opt/ros/melodic/lib/rqt_multiplot/rqt_multiplot"
    return rqt_multiplot_cmd


def Run(args):
    bag_play_cmd = MakeBagPlayCmd(args)
    rviz_cmd = MakeRvizCmd()
    rqt_multiplot_cmd = MakeRqtMultiPlotCmd()

    do_visualization = not args.norviz
    do_rqt_multiplot = not args.norqt
    if do_visualization:
        rviz_ps = subprocess.Popen(
            rviz_cmd, shell=True, executable="/bin/bash", stdout=FNULL, stderr=FNULL
        )
    bag_play_ps = subprocess.Popen(bag_play_cmd, shell=True, executable="/bin/bash")
    if do_rqt_multiplot:
        rqt_multiplot_ps = subprocess.Popen(
            rqt_multiplot_cmd, shell=True, executable="/bin/bash"
        )

    try:
        bag_play_ps.wait()
    except KeyboardInterrupt:
        bag_play_ps.send_signal(SIGINT)
        if do_visualization:
            rviz_ps.send_signal(SIGINT)
        if do_rqt_multiplot:
            rqt_multiplot_ps.send_signal(SIGINT)
    if do_visualization:
        rviz_ps.send_signal(SIGINT)
    if do_rqt_multiplot:
        rqt_multiplot_ps.send_signal(SIGINT)


def StartRoscore():
    subprocess.Popen(
        "roscore", shell=True, executable="/bin/bash", stdout=FNULL, stderr=FNULL
    )
    time.sleep(1.0)


if __name__ == "__main__":
    StartRoscore()
    args = ParseArgs()
    Run(args)
